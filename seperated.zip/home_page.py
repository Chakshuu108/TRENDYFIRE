"""
Home Page Module
Displays feature overview and application capabilities
"""

import streamlit as st


def show_home_page():
    """Display home page with 6 feature boxes"""
    
    # Add vertical spacing to ensure content starts below tabs
    st.markdown("<div style='margin-top: 30px;'></div>", unsafe_allow_html=True)
    
    # FIRST ROW: Main 3 feature cards
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.markdown("### 🌐 Web Scraping")
        st.write("Collect customer reviews and feedback from any URL automatically")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.markdown("### 🧠 NLP Analysis")
        st.write("Analyze sentiment, extract topics, and identify key themes from text data")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col3:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.markdown("### 📊 Forecasting")
        st.write("Predict future demand using 5 ML models including XGBoost and Gradient Boosting")
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Add spacing between rows
    st.markdown("<div style='margin-top: 20px;'></div>", unsafe_allow_html=True)
    
    # SECOND ROW: Additional 3 feature cards
    col4, col5, col6 = st.columns(3)
    
    with col4:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.markdown("### 💡 Insights")
        st.write("Generate strategic recommendations and comprehensive PDF reports with embedded visualizations")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col5:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.markdown("### 📊 Analytics")
        st.write("Deep dive into demand statistics, correlation analysis, model comparison, and feature importance")
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col6:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.markdown("### 🎨 Custom BI")
        st.write("Build unlimited custom visualizations with intelligent column detection and 11+ chart types")
        st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Feature details section
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown("""
        #### 🔹 Data Collection
        - **Upload historical demand data** (any CSV format)
        - **Scrape customer reviews** from web URLs
        - **Smart column detection** handles various formats automatically
        - **Supports multiple data sources** (CSV, web scraping, manual upload)
        
        #### 🔹 NLP Processing
        - **Text preprocessing** and cleaning
        - **Sentiment analysis** (VADER/TextBlob methods)
        - **Topic modeling** to identify key themes and patterns
        - **Extract insights** from customer feedback and reviews
        
        #### 🔹 Advanced Analytics
        - **Comprehensive statistical analysis** of demand patterns
        - **Correlation & relationship discovery** between features
        - **Model performance comparison** across all algorithms
        - **Feature importance visualization** to understand drivers
        - **Time-series decomposition** (trend, seasonality, residuals)
        """)
    
    with col2:
        st.markdown("""
        #### 🔹 Feature Engineering
        - **Combine demand and NLP features** for richer predictions
        - **Create time-based features** (day of week, month, seasonality)
        - **Generate lag features** (previous periods' demand)
        - **Calculate rolling statistics** (moving averages, trends)
        - **Automated feature selection** for optimal performance
        
        #### 🔹 Model Training & Forecasting
        - **5 Advanced ML Models**: XGBoost, Gradient Boosting, Random Forest, Linear Regression, SVR
        - **Automatic model comparison** - find the best performer
        - **Iterative forecasting** - realistic predictions over time horizon
        - **Confidence intervals** - understand prediction uncertainty
        - **Performance metrics**: MAE, RMSE, MAPE, R² Score
        
        #### 🔹 Insights & Reporting
        - **Strategic recommendations** based on analysis
        - **Comprehensive PDF reports** with embedded graphs
        - **Multiple visualization types** (8+ chart types available)
        - **Export capabilities** - download all data and charts
        - **Custom BI Builder** - create your own visualizations
        """)
    
    st.markdown("---")
    
    # Visualization types
    st.markdown("### 📊 8 Professional Visualization Types")
    
    viz_col1, viz_col2, viz_col3, viz_col4 = st.columns(4)
    
    with viz_col1:
        st.info("📈 **Line Chart**\nSmooth trend lines with fill")
    with viz_col2:
        st.info("📊 **Bar Chart**\nColor-coded value bars")
    with viz_col3:
        st.info("🎨 **Area Chart**\nFilled region visualization")
    with viz_col4:
        st.info("🔵 **Scatter Plot**\nData point distribution")
    
    viz_col5, viz_col6, viz_col7, viz_col8 = st.columns(4)
    
    with viz_col5:
        st.info("🕯️ **Candlestick**\nPrice-like high/low visualization")
    with viz_col6:
        st.info("🔥 **Heatmap**\nCalendar patterns & intensity")
    with viz_col7:
        st.info("📦 **Box Plot**\nStatistical distribution & outliers")
    with viz_col8:
        st.info("🎻 **Violin Plot**\nDensity distribution shape")
    
    st.markdown("---")
    
    # Custom BI Feature
    st.markdown("### 🎨 Custom BI Builder")
    st.success("🚀 Create unlimited custom visualizations from your data with intelligent column detection")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        **🧠 Smart Column Detection**
        - Automatically categorizes columns
        - Order/Transaction fields
        - Product & inventory data
        - Customer information
        - Time & calendar dimensions
        - Geographic location data
        """)
    
    with col2:
        st.markdown("""
        **📊 Build Any Chart**
        - 11+ chart types available
        - Drag & drop column selection
        - Multiple aggregation methods
        - Color coding by categories
        - Multi-graph dashboards
        - Side-by-side comparisons
        """)
    
    with col3:
        st.markdown("""
        **💾 Export Everything**
        - Download as interactive HTML
        - Export underlying data as CSV
        - Save entire dashboards
        - Share-ready visualizations
        - Print-friendly formats
        - Embed in presentations
        """)
    
    st.markdown("---")
    
    # Getting Started Guide
    st.markdown("### 🚀 Quick Start Guide")
    
    st.markdown("""
    1. **📁 Data Input Tab**: Upload your historical demand data (CSV) or scrape reviews from any website
    2. **🔍 NLP Analysis Tab**: Process text data, analyze sentiment, and extract topics
    3. **📈 Forecasting Tab**: Train ML models and generate future demand predictions
    4. **💡 Insights Tab**: Review strategic recommendations and generate PDF reports
    5. **📊 Analytics Tab**: Deep dive into statistics, correlations, and model performance
    6. **🎨 Custom BI Tab**: Build custom visualizations from all available data columns
    """)
    
    st.markdown("---")
    
    # Key Features Highlights
    st.markdown("### ⭐ Key Features & Capabilities")
    
    feature_col1, feature_col2, feature_col3 = st.columns(3)
    
    with feature_col1:
        st.markdown("""
        **🎯 Forecasting Excellence**
        - 5 ML models included
        - Automatic best model selection
        - Up to 90-day forecasts
        - Confidence intervals
        - Iterative prediction engine
        - Real-time performance metrics
        """)
    
    with feature_col2:
        st.markdown("""
        **🧠 NLP Intelligence**
        - Sentiment analysis (2 methods)
        - Topic modeling & extraction
        - Text preprocessing pipeline
        - Aggregate insights by date
        - Review impact on demand
        - Automated text cleaning
        """)
    
    with feature_col3:
        st.markdown("""
        **📊 Professional Reporting**
        - PDF reports with graphs
        - Multiple chart types
        - Strategic recommendations
        - Executive summaries
        - Download all outputs
        - Share-ready formats
        """)
    
    st.markdown("---")
    
    # Technical Specifications
    st.markdown("### ⚙️ Technical Specifications")
    
    tech_col1, tech_col2 = st.columns(2)
    
    with tech_col1:
        st.markdown("""
        **Machine Learning Models:**
        - XGBoost Regressor
        - Gradient Boosting
        - Random Forest
        - Linear Regression
        - Support Vector Regression (SVR)
        
        **Evaluation Metrics:**
        - Mean Absolute Error (MAE)
        - Root Mean Squared Error (RMSE)
        - Mean Absolute Percentage Error (MAPE)
        - R² Score (Coefficient of Determination)
        """)
    
    with tech_col2:
        st.markdown("""
        **NLP Capabilities:**
        - VADER Sentiment Analysis
        - TextBlob Sentiment Analysis
        - Topic Modeling (LDA)
        - Text Preprocessing & Cleaning
        
        **Data Processing:**
        - Smart column auto-detection
        - Missing value handling
        - Date parsing & formatting
        - Feature engineering automation
        - Lag & rolling features generation
        """)
    
    st.markdown("---")
    
    # Version Information
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.info("**Version**: 4.0 Enhanced")
    with col2:
        st.info("**Status**: ✅ All Bugs Fixed")
    with col3:
        st.info("**Latest Update**: Analytics + Custom BI")
    
    st.markdown("---")
    
    # Footer
    st.caption("💡 **Pro Tip**: Start by uploading demand data in the 'Data Input' tab, then enhance predictions with customer reviews!")
