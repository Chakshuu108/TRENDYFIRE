"""
Data Input Page Module
Handles CSV uploads, web scraping, and intelligent column mapping
"""

import streamlit as st
import pandas as pd
import numpy as np
import requests
import re
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urljoin
from datetime import datetime, timedelta
import json
import hashlib
import random
from typing import Dict, List, Optional
import plotly.express as px
import plotly.graph_objects as go


# ============================================================================
# UNIVERSAL WEB SCRAPER
# ============================================================================

def scrape_url(url: str, max_items: int = 200) -> pd.DataFrame:
    """Universal web scraper for extracting reviews and data from any URL"""
    
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Accept-Language": "en-US,en;q=0.9",
    }

    PRICE_REGEX = re.compile(r'[₹$€£¥]\s*[\d,.]+')
    RATING_REGEX = re.compile(r'(\d+(\.\d+)?)\s*(/5|stars?)', re.I)
    DATE_REGEX = re.compile(r'\d{4}-\d{2}-\d{2}')

    def clean(text):
        return re.sub(r'\s+', ' ', text).strip() if text else None

    try:
        r = requests.get(url, headers=HEADERS, timeout=30)
        r.raise_for_status()
    except Exception as e:
        return pd.DataFrame({"error": [str(e)]})

    soup = BeautifulSoup(r.text, "html.parser")
    domain = urlparse(url).netloc

    page_title = clean(soup.title.text) if soup.title else None

    # Extract JSON-LD
    records = []

    for script in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(script.string)
            if isinstance(data, dict):
                records.append({
                    "title": data.get("name"),
                    "review_text": data.get("description"),
                    "rating": data.get("aggregateRating", {}).get("ratingValue"),
                    "price": data.get("offers", {}).get("price"),
                    "date": data.get("datePublished"),
                    "url": data.get("url"),
                    "source_url": url,
                    "domain": domain,
                    "page_title": page_title,
                    "scraped_at": datetime.utcnow()
                })
        except:
            pass

    # HTML Content Blocks
    blocks = soup.find_all(["article", "section", "div", "li"])

    seen = set()

    for block in blocks:
        text = clean(block.get_text(" ", strip=True))
        if not text or len(text) < 40:
            continue

        signature = hashlib.md5(text[:300].encode()).hexdigest()
        if signature in seen:
            continue
        seen.add(signature)

        price = None
        rating = None

        price_match = PRICE_REGEX.search(text)
        if price_match:
            price = float(re.sub(r"[^\d.]", "", price_match.group()))

        rating_match = RATING_REGEX.search(text)
        if rating_match:
            rating = float(rating_match.group(1))

        link = block.find("a", href=True)
        image = block.find("img")

        records.append({
            "title": clean(block.find(["h1","h2","h3","h4","h5","h6"]).text) 
                     if block.find(["h1","h2","h3","h4","h5","h6"]) else None,
            "review_text": text[:500],
            "full_text": text,
            "rating": rating,
            "price": price,
            "url": urljoin(url, link["href"]) if link else None,
            "image_url": urljoin(url, image["src"]) if image and image.get("src") else None,
            "source_url": url,
            "domain": domain,
            "page_title": page_title,
            "scraped_at": datetime.utcnow(),
            "word_count": len(text.split())
        })

        if len(records) >= max_items:
            break

    if not records:
        return pd.DataFrame(columns=[
            "title","review_text","rating","price","url","domain"
        ])

    df = pd.DataFrame(records)

    df["rating"] = pd.to_numeric(df.get("rating"), errors="coerce")
    df["price"] = pd.to_numeric(df.get("price"), errors="coerce")
    df["date"] = pd.to_datetime(df.get("date"), errors="coerce")

    return df


# ============================================================================
# SAMPLE DATA GENERATION
# ============================================================================

def create_sample_review_data(num_samples: int = 50) -> pd.DataFrame:
    """Create sample review data for demonstration"""
    
    sample_reviews = [
        "Great product! Exactly what I needed. Fast shipping too.",
        "Not bad but could be better. The quality is okay for the price.",
        "Terrible experience. Product broke after one week.",
        "Love it! Best purchase I've made in a while.",
        "Decent product but overpriced in my opinion.",
        "Five stars! Excellent quality and great customer service.",
        "Would not recommend. Very disappointed with this purchase.",
        "Pretty good overall. Met my expectations.",
        "Amazing! Worth every penny. Highly recommend!",
        "Meh, it's okay. Nothing special but does the job.",
    ]
    
    reviews = []
    base_date = datetime.now()
    
    for i in range(num_samples):
        date = base_date - timedelta(days=random.randint(0, 90))
        rating = random.choice([1, 2, 3, 4, 5])
        
        if rating >= 4:
            text = random.choice([r for r in sample_reviews if any(word in r.lower() for word in ['great', 'excellent', 'love', 'amazing'])])
        elif rating <= 2:
            text = random.choice([r for r in sample_reviews if any(word in r.lower() for word in ['terrible', 'poor', 'disappointed'])])
        else:
            text = random.choice([r for r in sample_reviews if any(word in r.lower() for word in ['okay', 'decent', 'meh'])])
        
        reviews.append({
            'review_text': text,
            'date': date.strftime('%Y-%m-%d'),
            'rating': rating,
            'source': 'sample_data'
        })
    
    return pd.DataFrame(reviews)


# ============================================================================
# COLUMN DETECTION AND MAPPING
# ============================================================================

class ColumnMapper:
    """Intelligent column detection and mapping for various CSV formats"""
    
    DATE_PATTERNS = [
        r'date', r'time', r'datetime', r'timestamp', r'created', r'published',
        r'posted', r'review_date', r'purchase_date', r'order_date', r'day'
    ]
    
    TEXT_PATTERNS = [
        r'review', r'text', r'comment', r'feedback', r'description', r'content',
        r'message', r'body', r'summary', r'opinion', r'note'
    ]
    
    RATING_PATTERNS = [
        r'rating', r'score', r'stars', r'rate', r'grade', r'rank'
    ]
    
    DEMAND_PATTERNS = [
        r'demand', r'sales', r'quantity', r'units', r'volume', r'orders',
        r'sold', r'revenue', r'count', r'total'
    ]
    
    @staticmethod
    def fuzzy_match(column_name: str, patterns: List[str]) -> float:
        """Calculate fuzzy match score between column name and patterns"""
        column_lower = column_name.lower().strip()
        best_score = 0
        
        for pattern in patterns:
            if re.search(pattern, column_lower):
                best_score = max(best_score, 1.0)
            elif pattern in column_lower or column_lower in pattern:
                best_score = max(best_score, 0.7)
        
        return best_score
    
    @classmethod
    def detect_column_type(cls, df: pd.DataFrame, column: str) -> Dict[str, float]:
        """Detect what type of data a column likely contains"""
        scores = {
            'date': 0,
            'text': 0,
            'rating': 0,
            'demand': 0
        }
        
        scores['date'] = cls.fuzzy_match(column, cls.DATE_PATTERNS)
        scores['text'] = cls.fuzzy_match(column, cls.TEXT_PATTERNS)
        scores['rating'] = cls.fuzzy_match(column, cls.RATING_PATTERNS)
        scores['demand'] = cls.fuzzy_match(column, cls.DEMAND_PATTERNS)
        
        sample = df[column].dropna().head(20)
        
        if len(sample) > 0:
            try:
                pd.to_datetime(sample)
                scores['date'] += 0.5
            except:
                pass
            
            if pd.api.types.is_numeric_dtype(df[column]):
                if df[column].max() <= 10 and df[column].min() >= 0:
                    scores['rating'] += 0.3
                scores['demand'] += 0.2
            
            if pd.api.types.is_string_dtype(df[column]):
                avg_length = sample.astype(str).str.len().mean()
                if avg_length > 20:
                    scores['text'] += 0.5
        
        return scores
    
    @classmethod
    def auto_detect_columns(cls, df: pd.DataFrame) -> Dict[str, Optional[str]]:
        """Automatically detect and map columns to required fields"""
        mapping = {
            'date': None,
            'text': None,
            'rating': None,
            'demand': None
        }
        
        column_scores = {}
        for column in df.columns:
            column_scores[column] = cls.detect_column_type(df, column)
        
        for col_type in mapping.keys():
            best_col = None
            best_score = 0
            
            for column, scores in column_scores.items():
                if scores[col_type] > best_score:
                    best_score = scores[col_type]
                    best_col = column
            
            if best_score > 0.3:
                mapping[col_type] = best_col
        
        return mapping
    
    @classmethod
    def get_mapping_confidence(cls, df: pd.DataFrame, mapping: Dict[str, Optional[str]]) -> Dict[str, float]:
        """Get confidence scores for each mapped column"""
        confidence = {}
        
        for col_type, column in mapping.items():
            if column is not None:
                scores = cls.detect_column_type(df, column)
                confidence[col_type] = scores[col_type]
            else:
                confidence[col_type] = 0.0
        
        return confidence


def show_column_mapper_ui(df: pd.DataFrame, data_type: str = 'review', context: str = 'main') -> Dict[str, str]:
    """Display interactive UI for column mapping"""
    
    mapper = ColumnMapper()
    auto_mapping = mapper.auto_detect_columns(df)
    confidence = mapper.get_mapping_confidence(df, auto_mapping)
    
    st.markdown("#### 🎯 Smart Column Detection")
    
    cols = st.columns(4)
    for idx, (field, column) in enumerate(auto_mapping.items()):
        with cols[idx % 4]:
            if column:
                conf_pct = confidence[field] * 100
                color = "🟢" if conf_pct > 70 else "🟡" if conf_pct > 40 else "🔴"
                st.metric(field.title(), column, f"{color} {conf_pct:.0f}%")
            else:
                st.metric(field.title(), "Not detected", "🔴 0%")
    
    st.markdown("---")
    st.markdown("#### Adjust Mappings (if needed)")
    
    final_mapping = {}
    
    if data_type == 'review':
        required_fields = {
            'date': 'Date/Time column',
            'text': 'Review/Comment text',
            'rating': 'Rating (optional)'
        }
    else:
        required_fields = {
            'date': 'Date/Time column',
            'demand': 'Demand/Sales/Quantity'
        }
    
    col1, col2 = st.columns(2)
    
    for idx, (field, description) in enumerate(required_fields.items()):
        with col1 if idx % 2 == 0 else col2:
            default_val = auto_mapping.get(field)
            default_idx = 0
            
            options = ['-- None --'] + list(df.columns)
            
            if default_val and default_val in df.columns:
                default_idx = options.index(default_val)
            
            selected = st.selectbox(
                f"**{description}**",
                options=options,
                index=default_idx,
                key=f"{context}_map_{field}"
            )
            
            if selected != '-- None --':
                final_mapping[field] = selected
    
    return final_mapping


# ============================================================================
# ENHANCED VISUALIZATIONS
# ============================================================================

def create_enhanced_demand_plot(df, chart_type='line'):
    """Create enhanced demand visualization with multiple chart types"""
    
    if chart_type == 'line':
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=df['date'],
            y=df['demand'],
            mode='lines',
            name='Demand',
            line=dict(color='#6366f1', width=3),
            fill='tozeroy',
            fillcolor='rgba(99, 102, 241, 0.1)'
        ))
        
    elif chart_type == 'area':
        fig = px.area(df, x='date', y='demand', 
                     color_discrete_sequence=['#6366f1'])
        
    elif chart_type == 'bar':
        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=df['date'],
            y=df['demand'],
            marker=dict(
                color=df['demand'],
                colorscale='Purples',
                showscale=True,
                colorbar=dict(title="Demand")
            )
        ))
        
    elif chart_type == 'scatter':
        fig = px.scatter(df, x='date', y='demand',
                        size='demand',
                        color='demand',
                        color_continuous_scale='Purples')
        
    elif chart_type == 'candlestick':
        df_roll = df.copy()
        df_roll['high'] = df_roll['demand'].rolling(7, center=True).max()
        df_roll['low'] = df_roll['demand'].rolling(7, center=True).min()
        df_roll['open'] = df_roll['demand'].shift(1)
        df_roll['close'] = df_roll['demand']
        
        fig = go.Figure(data=[go.Candlestick(
            x=df_roll['date'],
            open=df_roll['open'],
            high=df_roll['high'],
            low=df_roll['low'],
            close=df_roll['close'],
            increasing_line_color='#6366f1',
            decreasing_line_color='#ef4444'
        )])
        
    elif chart_type == 'heatmap':
        df_heat = df.copy()
        df_heat['week'] = df_heat['date'].dt.isocalendar().week
        df_heat['dow'] = df_heat['date'].dt.dayofweek
        pivot = df_heat.pivot_table(values='demand', index='dow', columns='week', aggfunc='mean')
        
        fig = go.Figure(data=go.Heatmap(
            z=pivot.values,
            x=pivot.columns,
            y=['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            colorscale='Purples',
            showscale=True
        ))
        fig.update_layout(
            xaxis_title='Week of Year',
            yaxis_title='Day of Week'
        )
        
    elif chart_type == 'box':
        df_box = df.copy()
        df_box['month'] = df_box['date'].dt.to_period('M').astype(str)
        fig = px.box(df_box, x='month', y='demand',
                    color_discrete_sequence=['#6366f1'])
        fig.update_traces(marker=dict(opacity=0.7))
        
    elif chart_type == 'violin':
        df_vio = df.copy()
        df_vio['month'] = df_vio['date'].dt.to_period('M').astype(str)
        fig = px.violin(df_vio, x='month', y='demand',
                       box=True, points='all',
                       color_discrete_sequence=['#6366f1'])
    
    # Common styling
    fig.update_layout(
        title=dict(
            text='<b>Historical Demand Trend</b>',
            font=dict(size=24, family='Arial Black', color='#ffffff')
        ),
        plot_bgcolor='#1f2937',
        paper_bgcolor='#111827',
        font=dict(color='#ffffff', family='Arial'),
        xaxis=dict(
            title='<b>Date</b>',
            gridcolor='#374151',
            showgrid=True,
            zeroline=False
        ),
        yaxis=dict(
            title='<b>Demand</b>',
            gridcolor='#374151',
            showgrid=True,
            zeroline=False
        ),
        hovermode='x unified',
        height=500,
        margin=dict(t=80, b=60, l=60, r=40)
    )
    
    return fig


# ============================================================================
# DATA INPUT PAGE
# ============================================================================

def show_data_input_page():
    """Data input page with intelligent column mapping"""
    
    tab1, tab2, tab3 = st.tabs(["📁 Upload Demand Data", "🌐 Scrape Reviews", "📋 Upload Review Data"])
    
    with tab1:
        st.markdown("### Upload Historical Demand Data")
        
        uploaded_file = st.file_uploader("Choose CSV file", type=['csv'], key='demand_upload')
        
        if uploaded_file:
            try:
                df = pd.read_csv(uploaded_file)
                st.success("✅ Data uploaded successfully!")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Total Records", len(df))
                with col2:
                    st.metric("Columns", len(df.columns))
                with col3:
                    st.metric("Memory", f"{df.memory_usage(deep=True).sum() / 1024:.1f} KB")
                
                st.markdown("#### Raw Data Preview")
                st.dataframe(df.head(10), use_container_width=True)
                
                st.markdown("---")
                
                column_mapping = show_column_mapper_ui(df, data_type='demand', context='demand')
                
                if column_mapping.get('date') and column_mapping.get('demand'):
                    if st.button("✅ Confirm and Process Data", type="primary"):
                        try:
                            # Store the FULL original CSV for Custom BI
                            st.session_state.original_csv_data = df.copy()
                            
                            # Process only date and demand for forecasting
                            df_processed = df[[column_mapping['date'], column_mapping['demand']]].copy()
                            df_processed.columns = ['date', 'demand']
                            
                            df_processed['date'] = pd.to_datetime(df_processed['date'], errors='coerce')
                            df_processed['demand'] = pd.to_numeric(df_processed['demand'], errors='coerce')
                            df_processed = df_processed.dropna(subset=['date', 'demand'])
                            df_processed = df_processed.sort_values('date').reset_index(drop=True)
                            
                            st.session_state.demand_data = df_processed
                            st.session_state.data_loaded = True
                            
                            st.success(f"✅ Processed {len(df_processed)} records successfully!")
                            
                            col1, col2, col3, col4 = st.columns(4)
                            with col1:
                                st.metric("Start Date", df_processed['date'].min().strftime('%Y-%m-%d'))
                            with col2:
                                st.metric("End Date", df_processed['date'].max().strftime('%Y-%m-%d'))
                            with col3:
                                st.metric("Avg Demand", f"{df_processed['demand'].mean():.2f}")
                            with col4:
                                st.metric("Total Demand", f"{df_processed['demand'].sum():.0f}")
                            
                        except Exception as e:
                            st.error(f"Error processing data: {str(e)}")
                    
                    # Show chart selector
                    if st.session_state.data_loaded and st.session_state.demand_data is not None:
                        st.markdown("---")
                        st.markdown("### 📊 Visualize Your Data")
                        
                        chart_type = st.selectbox(
                            "Select Chart Type",
                            options=['line', 'area', 'bar', 'scatter', 'candlestick', 'heatmap', 'box', 'violin'],
                            format_func=lambda x: {
                                'line': '📈 Line Chart',
                                'area': '🎨 Area Chart',
                                'bar': '📊 Bar Chart',
                                'scatter': '🔵 Scatter Plot',
                                'candlestick': '🕯️ Candlestick',
                                'heatmap': '🔥 Heatmap',
                                'box': '📦 Box Plot',
                                'violin': '🎻 Violin Plot'
                            }[x],
                            key='demand_chart_type'
                        )
                        
                        fig = create_enhanced_demand_plot(st.session_state.demand_data, chart_type)
                        st.plotly_chart(fig, use_container_width=True)
                else:
                    st.warning("⚠️ Please map at least Date and Demand columns")
            
            except Exception as e:
                st.error(f"Error loading file: {str(e)}")
    
    with tab2:
        st.markdown("### Scrape Customer Reviews from URL")
        st.info("🌟 Universal Web Scraper - Works on ANY website!")
        
        url_input = st.text_input("Enter URL", placeholder="https://example.com/reviews")
        max_reviews = st.slider("Max Reviews", 10, 200, 50)
        
        if st.button("🔍 Start Scraping", type="primary"):
            if url_input:
                with st.spinner("🌐 Scraping website... This may take a moment..."):
                    try:
                        scraped_df = scrape_url(url_input, max_items=max_reviews)
                        
                        if 'error' in scraped_df.columns:
                            st.error(f"Error scraping URL: {scraped_df['error'].iloc[0]}")
                            st.info("Generating sample data for demonstration...")
                            scraped_df = create_sample_review_data(max_reviews)
                        elif scraped_df.empty:
                            st.warning("No data found on the website. Generating sample data...")
                            scraped_df = create_sample_review_data(max_reviews)
                        
                        if not scraped_df.empty:
                            st.success(f"✅ Collected {len(scraped_df)} reviews!")
                            st.session_state.scraped_data = scraped_df
                            
                            col1, col2, col3, col4 = st.columns(4)
                            with col1:
                                st.metric("Total Reviews", len(scraped_df))
                            with col2:
                                if 'rating' in scraped_df.columns:
                                    avg_rating = scraped_df['rating'].mean()
                                    st.metric("Avg Rating", f"{avg_rating:.2f}" if not pd.isna(avg_rating) else "N/A")
                                else:
                                    st.metric("Avg Rating", "N/A")
                            with col3:
                                if 'author' in scraped_df.columns:
                                    unique_authors = scraped_df['author'].nunique()
                                    st.metric("Unique Authors", unique_authors)
                                else:
                                    st.metric("Unique Authors", "N/A")
                            with col4:
                                if 'domain' in scraped_df.columns:
                                    st.metric("Source", scraped_df['domain'].iloc[0] if len(scraped_df) > 0 else "N/A")
                                else:
                                    st.metric("Source", "N/A")
                            
                            st.dataframe(scraped_df.head(10), use_container_width=True)
                            
                            st.markdown("### 📥 Download Scraped Data")
                            csv_data = scraped_df.to_csv(index=False)
                            domain = urlparse(url_input).netloc.replace(".", "_")
                            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                            file_name = f"scraped_{domain}_{timestamp}.csv"

                            st.download_button(
                                label="⬇️ Download Scraped CSV",
                                data=csv_data,
                                file_name=file_name,
                                mime="text/csv",
                                use_container_width=True
                            )

                    except Exception as e:
                        st.error(f"Error: {str(e)}")
                        st.info("Generating sample data for demonstration...")
                        scraped_df = create_sample_review_data(max_reviews)
                        st.session_state.scraped_data = scraped_df
                        st.dataframe(scraped_df.head(10), use_container_width=True)
            else:
                st.warning("Please enter a URL")
    
    with tab3:
        st.markdown("### Upload Existing Review Data")
        
        review_file = st.file_uploader("Choose CSV file", type=['csv'], key='review_upload')
        
        if review_file:
            try:
                review_df = pd.read_csv(review_file)
                st.success("✅ Review data uploaded!")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Total Reviews", len(review_df))
                with col2:
                    st.metric("Columns", len(review_df.columns))
                
                st.dataframe(review_df.head(10), use_container_width=True)
                
                st.markdown("---")
                
                column_mapping = show_column_mapper_ui(review_df, data_type='review', context='review')
                
                if column_mapping.get('date') and column_mapping.get('text'):
                    if st.button("✅ Confirm Review Data", type="primary"):
                        try:
                            cols_to_extract = [column_mapping['date'], column_mapping['text']]
                            new_col_names = ['date', 'review_text']
                            
                            if column_mapping.get('rating'):
                                cols_to_extract.append(column_mapping['rating'])
                                new_col_names.append('rating')
                            
                            processed_review_df = review_df[cols_to_extract].copy()
                            processed_review_df.columns = new_col_names
                            
                            processed_review_df['date'] = pd.to_datetime(
                                processed_review_df['date'], errors='coerce'
                            )
                            
                            processed_review_df = processed_review_df.dropna(subset=['date'])
                            
                            st.session_state.scraped_data = processed_review_df
                            
                            st.success(f"✅ Processed {len(processed_review_df)} reviews!")
                            st.dataframe(processed_review_df.head(10), use_container_width=True)
                            
                        except Exception as e:
                            st.error(f"Error: {str(e)}")
                else:
                    st.warning("⚠️ Please map at least Date and Text columns")
            
            except Exception as e:
                st.error(f"Error: {str(e)}")
